package com.example.service.impl;

import com.example.mapper.DptMapper;
import com.example.pojo.Dept;
import com.example.service.DptService;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DptServiceImpl implements DptService {
   @Autowired
   private DptMapper dptMapper;
    @Override
    public List<Dept> findAll() {
        return dptMapper.findAll();
    }
}
