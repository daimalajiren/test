package com.example.service;

import com.example.pojo.Dept;

import java.util.List;

public interface DptService {
    List<Dept> findAll();
}
