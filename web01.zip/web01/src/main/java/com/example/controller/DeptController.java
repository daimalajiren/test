package com.example.controller;

import com.example.pojo.Dept;
import com.example.pojo.Result;
import com.example.service.DptService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class DeptController {

    @Autowired
    private DptService dptService;
    //@RequestMapping(value = "/depts")
    @GetMapping("/depts")
        public Result list(){
        System.out.println("查询部门信息");
        List<Dept> deptList = dptService.findAll();

        return Result.success(deptList);
        }
}
